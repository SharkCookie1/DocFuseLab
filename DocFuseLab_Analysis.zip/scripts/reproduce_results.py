"""Recompute confirmation comparisons from the released numerical records."""
from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARMS = ("plain_set", "setr_iri_budget", "mmkp_context", "mmr", "set_graph", "strong_chain", "joint")
EXTRA_ARMS = ("full_context", "annotation_reference")


def read_json(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def paired_counts(rows, comparator):
    wins = losses = ties = 0
    for row in rows:
        joint = row["arms"]["joint"]["em"]
        other = row["arms"][comparator]["em"]
        require(joint in (0, 1) and other in (0, 1), "Correctness must be binary.")
        wins += joint > other
        losses += joint < other
        ties += joint == other
    discordant = wins + losses
    probability = (
        min(1.0, 2 * sum(math.comb(discordant, k) for k in range(min(wins, losses) + 1))
            / (2 ** discordant))
        if discordant else 1.0
    )
    return {
        "comparator": comparator,
        "n": len(rows),
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "difference": (wins - losses) / len(rows),
        "exact_mcnemar_p": probability,
    }


def recompute():
    rows = read_json("records/confirmation_outcomes.json")
    summaries = read_json("data/summary122.json")
    require(len(rows) == 300, "Expected 300 confirmation records.")
    require(len({row["qid"] for row in rows}) == 300, "Duplicate question identifier.")
    require(len({row["analysis_cluster"] for row in rows}) == 300, "Repeated confirmation cluster.")
    grouped = {name: [row for row in rows if row["condition"] == name]
               for name in ("conflict", "clean")}
    require(len(grouped["conflict"]) == 200 and len(grouped["clean"]) == 100,
            "Confirmation cohort composition differs from the frozen protocol.")
    totals = []
    for name, group in grouped.items():
        for arm in ARMS + EXTRA_ARMS:
            outcomes = [row["arms"][arm] for row in group]
            if arm in ARMS:
                require(all(outcome["source_tokens"] <= 256 for outcome in outcomes),
                        f"Source-token cap exceeded: {name}/{arm}.")
            total = {
                "condition": name,
                "arm": arm,
                "n": len(group),
                "correct": int(sum(outcome["em"] for outcome in outcomes)),
                "accuracy": sum(outcome["em"] for outcome in outcomes) / len(group),
                "mean_f1": sum(outcome["f1"] for outcome in outcomes) / len(group),
                "false_conflicts": int(sum(outcome["false_conflict"] for outcome in outcomes)),
                "invalid": int(sum(not outcome["valid"] for outcome in outcomes)),
                "mean_source_tokens": sum(outcome["source_tokens"] for outcome in outcomes) / len(group),
            }
            saved = summaries["groups"][name]["arms"][arm]
            for key in ("correct", "accuracy", "mean_f1", "false_conflicts", "invalid", "mean_source_tokens"):
                require(math.isclose(total[key], saved[key], rel_tol=1e-10, abs_tol=1e-10),
                        f"Numerical record and summary disagree: {name}/{arm}/{key}.")
            totals.append(total)

    comparisons = [paired_counts(grouped["conflict"], arm)
                   for arm in ("plain_set", "setr_iri_budget", "mmkp_context", "strong_chain")]
    saved = summaries["groups"]["conflict"]["supplemental_joint_vs_mmkp"]
    mmkp = next(c for c in comparisons if c["comparator"] == "mmkp_context")
    for key in ("wins", "losses", "ties", "difference", "exact_mcnemar_p"):
        require(math.isclose(mmkp[key], saved[key], rel_tol=1e-12, abs_tol=1e-15),
                "Supplemental paired comparison differs: " + key)
    costs = {key: sum(r["arms"]["mmkp_context"]["logical_reader_cost"][key] for r in rows)
             for key in ("calls", "input_tokens", "output_tokens", "seconds")}
    for key, value in costs.items():
        require(math.isclose(value, summaries["mmkp_supplement"]["new_reader_physical_cost"][key],
                             rel_tol=1e-10, abs_tol=1e-10), "MMKP cost differs: " + key)
    annotations = {r["qid"]: r for r in read_json("records/mmkp_selection_diagnostics.json")}
    measured = {}
    for arm in ("plain_set", "joint", "mmr", "mmkp_context"):
        measured[arm] = {
            "n": len(rows),
            "mean_units": sum(len(r["arms"][arm]["ids"]) for r in rows) / len(rows),
            "unknown": sum(r["arms"][arm]["unknown"] for r in rows),
            "both_annotated_endpoints": sum(set(annotations[r["qid"]]["annotated_endpoint_ids"])
                                            <= set(r["arms"][arm]["ids"]) for r in grouped["conflict"]),
            "annotated_bilateral_ids": sum(set(annotations[r["qid"]]["annotated_bilateral_ids"])
                                           <= set(r["arms"][arm]["ids"]) for r in grouped["conflict"]),
        }
    require(measured == read_json("data/selection_measures122.json"), "Selection diagnostics differ.")
    reference = read_json("records/reference_diagnostics.json")
    resolved = reference["resolved"]
    feasible = [row for row in resolved
                if row["condition"] == "conflict" and row["reviewed_reference"]["fits256"]]
    diagnostic = {
        "resolved_cases": len(resolved),
        "feasible_conflict_references": len(feasible),
        "reference_correct": int(sum(row["reviewed_reference"]["correct"] for row in feasible)),
        "joint_correct": int(sum(row["prior_correct"]["joint"] for row in feasible)),
    }
    require(diagnostic == {"resolved_cases": 55, "feasible_conflict_references": 29,
                           "reference_correct": 18, "joint_correct": 6},
            "Reference diagnostic differs from the reported values.")
    return {"confirmation": totals, "paired_conflict_comparisons": comparisons,
            "reference_diagnostic": diagnostic, "mmkp_reader_cost": costs,
            "selection_diagnostics": measured}


def reproduce_mmkp_interval():
    """Replay the frozen cluster-bootstrap draw order; numpy is optional."""
    import numpy as np
    summary = read_json("data/summary122.json")
    by_id = {r["qid"]: r for r in read_json("records/confirmation_outcomes.json")}
    rows = [by_id[q] for q in summary["mmkp_supplement"]["analysis_order"]
            if by_id[q]["condition"] == "conflict"]
    groups = {}
    for row in rows:
        groups.setdefault(row["analysis_cluster"], []).append(
            row["arms"]["joint"]["em"] - row["arms"]["mmkp_context"]["em"])
    values = np.array([[sum(v), len(v)] for v in groups.values()], dtype=float)
    saved = summary["groups"]["conflict"]["supplemental_joint_vs_mmkp"]
    rng = np.random.default_rng(saved["bootstrap_seed"])
    draws = []
    for _ in range(20):
        sampled = values[rng.integers(0, len(values), size=(1000, len(values)))].sum(axis=1)
        draws.extend((sampled[:, 0] / sampled[:, 1]).tolist())
    interval = np.quantile(draws, [.025, .975]).tolist()
    require(np.allclose(interval, saved["percentile95"], rtol=0, atol=1e-12),
            "MMKP bootstrap interval differs.")
    return {"bootstrap_seed": saved["bootstrap_seed"], "replicates": len(draws),
            "percentile95": interval}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figures", action="store_true",
                        help="Also regenerate the two empirical figures (requires matplotlib and numpy).")
    parser.add_argument("--bootstrap", action="store_true",
                        help="Replay the MMKP paired cluster-bootstrap interval (requires numpy).")
    args = parser.parse_args()
    print("Checking numerical records...", flush=True)
    report = recompute()
    if args.bootstrap:
        report["mmkp_bootstrap"] = reproduce_mmkp_interval()
    output = ROOT / "reproduced"
    output.mkdir(exist_ok=True)
    (output / "confirmation_checks.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    with (output / "confirmation_results.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=report["confirmation"][0].keys())
        writer.writeheader()
        writer.writerows(report["confirmation"])
    print("Rebuilding the eight manuscript tables...", flush=True)
    (ROOT / "tables").mkdir(exist_ok=True)
    subprocess.run([sys.executable, str(ROOT / "scripts/build_tables.py")],
                   check=True, cwd=ROOT)
    if args.figures:
        print("Rebuilding empirical figures...", flush=True)
        subprocess.run([sys.executable, str(ROOT / "plot_sources/generate_paper_figures.py")],
                       check=True, cwd=ROOT)
    print("Complete. Recomputed records: reproduced/; manuscript tables: tables/.", flush=True)


if __name__ == "__main__":
    main()

