"""MMKP context adaptation. See third_party/mmkp/LICENSE and METHOD_NOTE.txt."""
from pathlib import Path
import gc, math, os, time
import numpy as np
import common98 as c

def bert_window_inputs(tokenizer,content_ids):
    """Apply the pinned tokenizer's single-sequence [CLS] A [SEP] template."""
    if tokenizer.cls_token_id is None or tokenizer.sep_token_id is None:
        raise ValueError('The pinned BERT special tokens are missing')
    ids=[tokenizer.cls_token_id]+list(content_ids)+[tokenizer.sep_token_id]
    return {'input_ids':ids,'token_type_ids':[0]*len(ids),'attention_mask':[1]*len(ids)}

def validate_input(row):
    if set(row)!={'qid','question','options','units','rank_order','rank_scores'}:
        raise ValueError('Unexpected inference field; evaluation labels are not allowed')
    ids=[u['id'] for u in row['units']]
    if ids!=sorted(set(ids)) or sorted(row['rank_order'])!=ids:
        raise ValueError('Invalid source/rank identities')
    if len(row['rank_scores'])!=len(ids) or not all(math.isfinite(v) for v in row['rank_scores']):
        raise ValueError('Invalid frozen rank scores')
    for u in row['units']:
        if set(u)!={'id','text','tokens'} or type(u['id']) is not int or type(u['tokens']) is not int or u['tokens']<1:
            raise ValueError('Invalid source unit')

def build_groups(similarity,threshold):
    n=len(similarity);used=set();groups=[]
    for i in range(n):
        if i in used:continue
        group=[i];used.add(i)
        for j in range(i+1,n):
            if j not in used and similarity[i,j]>=threshold:group.append(j);used.add(j)
        groups.append(group)
    return groups

def exact_mmkp(groups,values,costs,redundancy,budget,red_budget):
    """Exact multiple-choice two-resource DP; independent exhaustive tests verify it."""
    dp=np.full((budget+1,red_budget+1),-np.inf,dtype=np.float64);dp[0,0]=0.
    decisions=[]
    for group in groups:
        nxt=dp.copy();take=np.full(dp.shape,-1,dtype=np.int32)
        for i in group:
            w1=int(costs[i]);w2=int(redundancy[i])
            if not 0<w1 or not 0<=w2:raise ValueError('Invalid resource cost')
            if w1>budget or w2>red_budget:continue
            cand=dp[:budget+1-w1,:red_budget+1-w2]+values[i]
            dest=nxt[w1:,w2:];better=cand>dest
            dest[better]=cand[better];take[w1:,w2:][better]=i
        dp=nxt;decisions.append(take)
    end=np.unravel_index(np.argmax(dp),dp.shape);state=end;selected=[]
    for take in reversed(decisions):
        i=int(take[state])
        if i>=0:
            selected.append(i);state=(state[0]-costs[i],state[1]-redundancy[i])
    if state!=(0,0):raise RuntimeError('Invalid dynamic-programming traceback')
    selected.sort()
    if len(selected)!=len(set(selected)) or any(len(set(selected)&set(g))>1 for g in groups):
        raise RuntimeError('Multiple-choice constraint violated')
    if sum(costs[i] for i in selected)>budget or sum(redundancy[i] for i in selected)>red_budget:
        raise RuntimeError('Resource budget violated')
    value=float(dp[end])
    if not math.isclose(sum(values[i] for i in selected),value,abs_tol=1e-9):raise RuntimeError('Objective replay differs')
    return selected,value

def solve(row,query_vector,vectors,cfg):
    validate_input(row);order=row['rank_order'];units={u['id']:u for u in row['units']}
    x=np.asarray(vectors,dtype=np.float64);q=np.asarray(query_vector,dtype=np.float64)
    if x.shape!=(len(order),384) or q.shape!=(384,) or not np.isfinite(x).all() or not np.isfinite(q).all():
        raise ValueError('Invalid encoder vectors')
    norms=np.linalg.norm(x,axis=1)
    if (norms<1e-8).any() or np.linalg.norm(q)<1e-8:raise ValueError('Empty encoder vector')
    x=x/norms[:,None];q=q/np.linalg.norm(q)
    # The published implementation normalizes each cosine denominator with 1e-8.
    sim=np.clip((x@x.T)/((1.+1e-8)**2),-1.,1.);raw=x@q
    width=float(raw.max()-raw.min())
    rel=np.full(len(raw),.5) if width<1e-9 else (raw-raw.min())/(width+1e-9)
    groups=build_groups(sim,cfg['sim_threshold']);values=[0.]*len(order);red=[0]*len(order)
    for group in groups:
        for i in group:
            avg=float(np.mean([sim[i,j] for j in group if j!=i])) if len(group)>1 else 0.
            values[i]=cfg['alpha']*float(rel[i])+cfg['beta']*(1.-avg)
            red[i]=int(round(max(0.,avg)*cfg['redundancy_scale']))
    costs=[units[i]['tokens'] for i in order]
    if sum(costs)<=cfg['source_budget_tokens']:
        indices=list(range(len(order)));objective=None;mode='all_candidates_fit'
    else:
        indices,objective=exact_mmkp(groups,values,costs,red,cfg['source_budget_tokens'],cfg['redundancy_budget']);mode='exact_mmkp'
    ids=sorted(order[i] for i in indices)
    return {'ids':ids,'candidate_cost':sum(costs),'source_tokens':sum(units[i]['tokens'] for i in ids),
            'groups':[[order[i] for i in g] for g in groups],
            'ordered_ids':order,'values':values,'redundancy_costs':red,'query_scores':raw.tolist(),
            'objective':objective,'mode':mode}

class Encoder:
    def __init__(self,cfg,emit):
        self.cfg=cfg;spec=cfg['embedding']
        os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false')
        from offline_encoder121 import resolve_encoder
        started=time.perf_counter()
        print('[ENCODER] Verifying bundled BGE files. Offline loading only.',flush=True)
        folder,assets=resolve_encoder(Path(__file__).resolve().parent,cfg)
        import torch
        from transformers import AutoTokenizer,AutoModel
        self.torch=torch;torch.set_num_threads(4)
        self.tok=AutoTokenizer.from_pretrained(folder,local_files_only=True,trust_remote_code=False)
        probe='Encoder token boundary check.'
        native=self.tok(probe,add_special_tokens=True,return_attention_mask=True,return_token_type_ids=True)
        assembled=bert_window_inputs(self.tok,self.tok.encode(probe,add_special_tokens=False))
        if any(native[k]!=assembled[k] for k in assembled) or self.tok.num_special_tokens_to_add(pair=False)!=2:
            raise ValueError('Window inputs differ from the pinned native BERT template')
        self.model=AutoModel.from_pretrained(folder,local_files_only=True,trust_remote_code=False,use_safetensors=True).to('cpu').eval()
        self.model.requires_grad_(False)
        if self.model.config.model_type!='bert' or self.model.config.hidden_size!=384 or self.model.config.max_position_embeddings<512:
            raise ValueError('Unexpected encoder architecture')
        emit('encoder_identity.json',{'repo_id':spec['repo_id'],'revision':spec['revision'],'device':'cpu',
            'delivery':'bundled_offline_assets','asset_manifest_sha256':c.sha(Path(__file__).resolve().parent/'encoder_assets.json'),
            'preparation_seconds':time.perf_counter()-started,'files':[
                {'name':e['name'],'bytes':e['bytes'],'sha256':e['sha256']} for e in assets['files'] if e['name'] in spec['files']]})
    def encode(self,texts):
        torch=self.torch;chunks=[];owners=[];weights=[];vectors=np.zeros((len(texts),384),dtype=np.float64);lengths=0
        for i,text in enumerate(texts):
            ids=self.tok.encode(text,add_special_tokens=False,truncation=False);lengths+=len(ids)
            for start in range(0,max(1,len(ids)),510):
                seq=ids[start:start+510];chunks.append(bert_window_inputs(self.tok,seq))
                owners.append(i);weights.append(max(1,len(seq)))
        with torch.inference_mode():
            for start in range(0,len(chunks),16):
                batch=self.tok.pad(chunks[start:start+16],padding=True,return_tensors='pt')
                h=self.model(**batch).last_hidden_state[:,0,:].float()
                h=torch.nn.functional.normalize(h,p=2,dim=1).cpu().numpy()
                for j,v in enumerate(h):vectors[owners[start+j]]+=weights[start+j]*v
        norms=np.linalg.norm(vectors,axis=1,keepdims=True)
        if (norms<1e-8).any():raise ValueError('Empty encoded text')
        return vectors/norms,{'texts':len(texts),'windows':len(chunks),'content_tokens':lengths}
    def close(self):
        del self.model;gc.collect()

def prepare(root,rows,cfg):
    root=Path(root);folder=root/'_local/selector121';plans={};enc=None;durations=[]
    try:
        for index,row in enumerate(rows,1):
            validate_input(row);path=folder/(row['qid']+'.json')
            identity={'row_sha256':c.digest(row),'protocol_sha256':c.digest(cfg)}
            if path.exists():
                record=c.read(path);c.check_signed(record)
                if record['identity']!=identity:raise ValueError('Selector cache belongs to a different input/protocol')
                expected=solve(row,record['query_vector'],record['vectors'],cfg)
                if record['plan']!=expected:raise ValueError('Selector replay differs')
            else:
                if enc is None:
                    enc=Encoder(cfg,lambda n,o:c.save(root/'_local'/n,o))
                started=time.perf_counter();units={u['id']:u['text'] for u in row['units']}
                with c.heartbeat('BGE encoding '+row['qid']):
                    vec,counts=enc.encode([row['question']]+[units[i] for i in row['rank_order']])
                plan=solve(row,vec[0],vec[1:],cfg)
                record=c.signed({'identity':identity,'query_vector':vec[0].tolist(),'vectors':vec[1:].tolist(),
                                 'plan':plan,'encoder_counts':counts,'seconds':time.perf_counter()-started})
                c.save(path,record);durations.append(record['seconds'])
            plans[row['qid']]=dict(record['plan'],selector_record_sha256=record['record_sha256'])
            print(f'[SELECT {index}/{len(rows)}] {row["qid"]}; source tokens={plans[row["qid"]]["source_tokens"]}',flush=True)
    finally:
        if enc is not None:enc.close()
    return plans
