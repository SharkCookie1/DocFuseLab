"""Independent optimization and pipeline checks; fixtures never enter study results."""
from pathlib import Path
from contextlib import redirect_stdout
import io,itertools,json,random,tempfile,unittest
import numpy as np
import common98 as c
import selector121 as s
import method121 as m
import engine121 as e
from offline_encoder121 import resolve_encoder
from reader_jobs121 import run_jobs

class OptimizationTests(unittest.TestCase):
    def test_exact_solver_against_exhaustive_search(self):
        rng=random.Random(121202610)
        for _ in range(160):
            n=rng.randint(2,9);groups=[list(range(i,min(i+3,n))) for i in range(0,n,3)]
            costs=[rng.randint(1,6) for i in range(n)];red=[rng.randint(0,5) for i in range(n)]
            values=[rng.random() for i in range(n)];b=rng.randint(0,13);rb=rng.randint(0,9)
            ids,value=s.exact_mmkp(groups,values,costs,red,b,rb);optimum=0.
            for choices in itertools.product(*[[None]+g for g in groups]):
                chosen=[i for i in choices if i is not None]
                if sum(costs[i] for i in chosen)<=b and sum(red[i] for i in chosen)<=rb:
                    optimum=max(optimum,sum(values[i] for i in chosen))
            self.assertAlmostEqual(value,optimum,places=12)
    def test_selection_rejects_hidden_labels_and_preserves_budget(self):
        row={'qid':'q','question':'Q','options':[],'units':[{'id':i,'text':str(i),'tokens':10} for i in range(4)],'rank_order':[0,1,2,3],'rank_scores':[1.,.8,.6,.4]}
        cfg={'sim_threshold':.82,'alpha':.7,'beta':.3,'redundancy_scale':100.,'source_budget_tokens':20,'redundancy_budget':120}
        vec=np.eye(384)[:4];q=vec[0]
        result=s.solve(row,q,vec,cfg);self.assertLessEqual(result['source_tokens'],20)
        self.assertEqual(result,s.solve(row,q,vec,cfg))
        with self.assertRaises(ValueError):s.solve(dict(row,answer='hidden'),q,vec,cfg)
    def test_valid_sources_and_frozen_inputs(self):
        root=Path(__file__).resolve().parent
        rows=c.read(root/'data/inputs.json');self.assertEqual(len(rows),300)
        for row in rows:s.validate_input(row)
        refs=c.read(root/'evaluation/references105.json');self.assertEqual(sum(r['condition']=='conflict' for r in refs),200)
        self.assertEqual(sum(r['condition']=='clean' for r in refs),100)

class OfflineAssetsTests(unittest.TestCase):
    def fixture(self,root):
        cfg={'embedding':{'repo_id':'test/model','revision':'test-revision','files':['config.json','model.safetensors']}}
        folder=root/'encoder_assets/bge-small-en-v1.5';folder.mkdir(parents=True)
        for name in cfg['embedding']['files']:(folder/name).write_bytes(('fixture '+name).encode())
        entries=[{'name':p.name,'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in sorted(folder.iterdir())]
        c.save(root/'encoder_assets.json',dict(repo_id='test/model',revision='test-revision',files=entries))
        return cfg,folder
    def test_local_assets_are_verified_without_network(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as td:
            cfg,folder=self.fixture(Path(td))
            with patch('socket.socket.connect',side_effect=AssertionError('Network access attempted')):
                actual,manifest=resolve_encoder(td,cfg)
            self.assertEqual(actual,folder);self.assertEqual(manifest['revision'],'test-revision')
    def test_missing_and_corrupt_assets_stop_before_loading(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cfg,folder=self.fixture(root);p=folder/'model.safetensors';original=p.read_bytes()
            p.write_bytes(b'x'+original[1:])
            with self.assertRaisesRegex(ValueError,'changed'):resolve_encoder(root,cfg)
            p.unlink()
            with self.assertRaisesRegex(FileNotFoundError,'missing'):resolve_encoder(root,cfg)
    def test_revision_mismatch_and_unsafe_paths_are_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cfg,folder=self.fixture(root);wrong={'embedding':dict(cfg['embedding'],revision='other')}
            with self.assertRaisesRegex(ValueError,'revision'):resolve_encoder(root,wrong)
            manifest=c.read(root/'encoder_assets.json');manifest['files'].append(dict(manifest['files'][0],name='../escape'))
            c.save(root/'encoder_assets.json',manifest)
            with self.assertRaisesRegex(ValueError,'Unsafe'):resolve_encoder(root,cfg)

class FakeAudit:
    vocab=256
    def __init__(self):self.tok=self
    def input_ids(self,prompt):return list(prompt.encode('utf-8'))
    def cost(self,text):return len(text.encode('utf-8'))
    def decode(self,ids,skip_special_tokens=True):return bytes(ids).decode('utf-8')

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.row={'qid':'testq','question':'What value?','options':[],'units':[{'id':0,'text':'x','tokens':6}], 'rank_order':[0],'rank_scores':[1.]}
        self.plan={'ids':[0],'candidate_cost':6,'selector_record_sha256':'fixture'}
        self.cfg={'source_budget_tokens':256,'generation':{'max_input_tokens':6144,'check_max_new_tokens':384,'answer_max_new_tokens':192}}
        self.audit=FakeAudit();self.identity={'test':'temporary-only'}
    def output(self,spec,raw=None):
        raw=raw or ('{"check":"Original source inspected."}' if spec['stage']=='check' else '{"answer":"UNKNOWN"}')
        ids=list(raw.encode('utf-8'))
        return {'raw_text':raw,'input_ids':self.audit.input_ids(spec['prompt']),'output_token_ids':ids,'output_tokens':len(ids),
                'criterion_calls':len(ids),'seconds':.1,'max_new_tokens':self.cfg['generation'][spec['stage']+'_max_new_tokens'],'stop_reason':'fixture'}
    def execute(self,work,fn,donors=None):
        with redirect_stdout(io.StringIO()):
            return run_jobs(Path('.'),self.cfg,[self.row],{'testq':self.plan},self.identity,self.audit,donors or {},work,generator=fn)
    def test_invalid_output_is_retained(self):
        with tempfile.TemporaryDirectory() as td:
            self.execute(Path(td),lambda spec,partial:self.output(spec,'invalid JSON'))
            self.execute(Path(td),lambda *_:self.fail('Completed invalid output was retried'))
            rs,ps,ct,done=e.load_cache(td,[self.row],{'testq':self.plan},self.cfg,self.identity,self.audit,{})
            self.assertEqual(len(rs['testq']),1);self.assertFalse(next(iter(ct['testq']['decisions'].values()))['valid'])
    def test_interruption_resume_and_tamper_rejection(self):
        calls=[]
        def initial(spec,partial):
            calls.append(spec['stage'])
            if spec['stage']=='answer':partial(self.output(spec));raise KeyboardInterrupt()
            return self.output(spec)
        with tempfile.TemporaryDirectory() as td:
            work=Path(td)
            with self.assertRaises(KeyboardInterrupt):self.execute(work,initial)
            resumed=[]
            self.execute(work,lambda spec,partial:(resumed.append(spec['stage']) or self.output(spec)))
            self.assertEqual(resumed,['answer'])
            rs,ps,ct,done=e.load_cache(work,[self.row],{'testq':self.plan},self.cfg,self.identity,self.audit,{})
            self.assertEqual(len(ps['testq']),1);self.assertEqual(done,['testq'])
            p=next((work/'records/testq').glob('*.json'));bad=c.read(p);bad['seconds']=99.;c.save(p,bad)
            with self.assertRaises(ValueError):e.load_cache(work,[self.row],{'testq':self.plan},self.cfg,self.identity,self.audit,{})
    def test_identical_historical_call_is_reused(self):
        with tempfile.TemporaryDirectory() as td:
            first=Path(td)/'one';self.execute(first,lambda spec,partial:self.output(spec))
            rs,_,_,_=e.load_cache(first,[self.row],{'testq':self.plan},self.cfg,self.identity,self.audit,{})
            donors={}
            for spec in m.layout(self.row,self.plan,self.cfg,rs['testq']):
                if spec['kind']=='call':donors[m.cache_key('testq',spec['stage'],spec['prompt'])]={'record':rs['testq'][spec['key']],'prompt':spec['prompt'],'origin_step':121}
            self.execute(Path(td)/'two',lambda *_:self.fail('Identical historical call rerun'),donors)

if __name__=='__main__':unittest.main(verbosity=2)
